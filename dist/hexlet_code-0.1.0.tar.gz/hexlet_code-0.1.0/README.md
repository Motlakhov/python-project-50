### Hexlet tests and linter status:
[![Actions Status](https://github.com/Motlakhov/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Motlakhov/python-project-50/actions)

https://asciinema.org/a/0s0j4OFtmy2EgGbFygqQSYWkd
