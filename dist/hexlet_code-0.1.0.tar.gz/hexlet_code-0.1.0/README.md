### Hexlet tests and linter status:
[![Actions Status](https://github.com/Motlakhov/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Motlakhov/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/7694e0c8cf5fc4cd28c5/maintainability)](https://codeclimate.com/github/Motlakhov/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/7694e0c8cf5fc4cd28c5/test_coverage)](https://codeclimate.com/github/Motlakhov/python-project-50/test_coverage)

[![asciicast](https://asciinema.org/a/0s0j4OFtmy2EgGbFygqQSYWkd.svg)](https://asciinema.org/a/0s0j4OFtmy2EgGbFygqQSYWkd)

step 5
[![asciicast](https://asciinema.org/a/ROyWfNtMk4ediYCgFLXwCFqXx.svg)](https://asciinema.org/a/ROyWfNtMk4ediYCgFLXwCFqXx)

step 6
[![asciicast](https://asciinema.org/a/pQTjxYh4BnHnJu97hsTxzsO9K.svg)](https://asciinema.org/a/pQTjxYh4BnHnJu97hsTxzsO9K)